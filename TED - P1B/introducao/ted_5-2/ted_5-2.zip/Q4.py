amigos = ["Jair", "Cristiane", "Pedro", "João"]

for pessoa in amigos:
    print(f'Nome: {pessoa}\n')
