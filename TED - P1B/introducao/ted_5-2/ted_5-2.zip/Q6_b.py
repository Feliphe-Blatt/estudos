celebridades = ["Padre marcelo Rossi", "Tiririca",
                "Richard Rasmussen", "Angélica", "Luciano hulk"]

for pessoa in celebridades:
    print(f'Olá {pessoa}, vem jantar aqui!\n')
