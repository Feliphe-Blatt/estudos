amigos = ["Jair", "Cristiane", "Pedro", "João"]

for pessoa in amigos:
    print(f'Olá {pessoa}, como vai você?\n')
