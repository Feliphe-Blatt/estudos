celebridades = ["Padre marcelo Rossi", "Tiririca",
                "Richard Rasmussen", "Angélica", "Luciano hulk"]
