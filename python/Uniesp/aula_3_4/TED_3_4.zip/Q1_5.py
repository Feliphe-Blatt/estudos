print(type("String qualquer..."))
print(type(15))
print(type(5.5))
print(type(True))
