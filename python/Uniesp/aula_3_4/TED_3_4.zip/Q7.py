nome = str(input("qual seu nome?\n-> "))
print(f'Bom dia, {nome}!\n')
