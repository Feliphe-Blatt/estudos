num_1 = float(input("Digite o primeiro número: "))
num_2 = float(input("Digite o segundo número: "))
print(f'O valor da soma: {num_1} + {num_2} = {num_1 + num_2}')
