nome = str(input("Qual seu nome?\n-> "))
print(f'Olá {nome.upper()}, venho te convidar para a festa. Vai ter bolo!\n')
