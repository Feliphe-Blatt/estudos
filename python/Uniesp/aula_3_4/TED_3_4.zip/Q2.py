print("Eu amo programar com Python!")
