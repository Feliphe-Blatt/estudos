idade = int(input("Diga sua idade: "))
nome = str(input("Seu nome: "))
idade_futura = idade + 1
print(f'{nome}, em 2025 sua idade será: {idade} anos!\n')
