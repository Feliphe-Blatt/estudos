# a) (B = A * C) e (L ou V)
#       (7 = 2 * 3.5) e (F ou V)
#           (7 = 7) e (V)
#               V e V
#                   Verdadeiro!

# b) (B > A) ou (B = POT(A,A))
#       V ou (7 = pot(2, 2))
#           V ou F
#             Verdadeiro!

# c) L e B div A >= C ou não(A<=C)
#       falso e 7 / 2 >= 3.5 ou não(V)
#           F e (3.5 >= 3.5) ou F
#               F e V ou F
#                   Falso!

# d) não(L) ou V e (rad(A+B) >= C)
#       V ou V e (radiciação?(9) >= 3.5)
#           V e (3>=3.5)
#               Falso!

# e) ((B/A) = C) ou (B/A) <> C
#       V ou F
#           Verdadeiro!

# f) L ou (pot(B, A) <= C * 10 + A * B)
#      F ou (49 <= 35 + 14)
#       F ou (49 <= 49)
#           Verdadeiro!
