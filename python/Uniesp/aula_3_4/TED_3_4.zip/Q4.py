num = float(input("Digite um número: "))
num += 1357
num *= 8


num /= 5
num **= 2
