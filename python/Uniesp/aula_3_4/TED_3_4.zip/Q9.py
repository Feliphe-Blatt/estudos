num_1 = int(input("digite o primeiro número: "))
num_2 = int(input("digite o segundo número: "))
print(num_1/num_2)
