PI = 3.14
raio = float(input("\nqual o raio do círculo? "))
print(f'Perímetro da circunferência: {2*PI*raio}\n')
