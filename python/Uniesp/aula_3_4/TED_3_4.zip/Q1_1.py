meu_nome = "Feliphe"
nome_colega_1 = "Cristiane"
nome_colega_2 = "Jair"
