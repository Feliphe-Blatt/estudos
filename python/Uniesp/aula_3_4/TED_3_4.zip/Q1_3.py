nome_de_usuario = str(input("Digite o seu nome: "))
print(f'Olá {nome_de_usuario}, bom dia!')
