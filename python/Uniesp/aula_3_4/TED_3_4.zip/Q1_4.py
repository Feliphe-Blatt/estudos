num = float(input("\nDigite um valor para formatar em Reais: "))
print(f'O valor em Reais é: R${num}\n')
